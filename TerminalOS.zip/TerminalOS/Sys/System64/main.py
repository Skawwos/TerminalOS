# ============= ВАЖНОЕ ==================
def typewriter(text, delay=0.02, end="\n"):
    for char in text:
        print(char, end='', flush=True)
        time.sleep(delay)
    print(end, end='', flush=True)


    
# ========== Библиотеки =================
import os
import sys
import hashlib
import json
import time
import re
from random import randint, choice
from ddgs import DDGS
import requests
from bs4 import BeautifulSoup

# ===================== ПУТИ =====================
ROOT_DIR = os.path.abspath(os.path.dirname(__file__))
SYSTEM_DIR = os.path.join(ROOT_DIR, "Sys", "System64")
USERCONFIG_DIR = os.path.join(ROOT_DIR, "UserConfig")
USERFILES_DIR = os.path.join(ROOT_DIR, "UserFiles")
CONFIG_PATH = os.path.join(USERCONFIG_DIR, "config.json")

for d in (SYSTEM_DIR, USERCONFIG_DIR, USERFILES_DIR):
    os.makedirs(d, exist_ok=True)

# ===================== ГЛОБАЛЫ =====================
IsActivated = False
name = ""
pass_create = 0
admin_mode = False
admin_pass = "root123"

tasks = []  # [{'text': str, 'due_ts': float|None, 'added_ts': float, 'notified': bool}]

# ===================== ЛОКАЛИЗАЦИЯ =====================
L = {
    "EN": {
        "welcome": "Welcome to TerminalOS!",
        "help_tip": "<help> to see more commands",
        "enter_pass": "Enter password: ",
        "wrong_pass": "Wrong password.",
        "set_name": "Enter your name: ",
        "set_pass": "Set numeric password (4-16 digits): ",
        "pass_num_only": "Password must be number!",
        "pass_len": "Password must be 4-16 digits!",
        "saving": "Saving password...",
        "select_lang": "Select language:\n<EN> English\n<RU> Russian (bugged)\n<UA> Ukrainian (bugged)",
        "unknown_lang": "Unknown language. Defaulting to English.",
        "activated": "✅ Activated!",
        "not_activated": "⚠ Not Activated.",
        "requires_activation": "❌ Requires activation.",
        "calc_menu": "1.+  2.-  3.*  4./",
        "again": "Again? (yes/no): ",
        "result": "Result:",
        "enter_text": "Enter text: ",
        "how_many": "How many times?: ",
        "unknown_cmd": "Unknown command. Type <help>.",
        "version": "TerminalOS v0.2.15 by Yan",
        "admin_on": "🔑 Admin mode enabled.",
        "admin_bad": "❌ Wrong admin password.",
        "admin_already": "Admin mode already enabled.",
        "access_denied": "Access denied. Type 'admin'.",
        "shutdown": "Shutting down...",
        "bsod": "😵 System failure. Press any key to reboot.",
        "crash_code": "System error occurred! STOP CODE: ",
        "file_saved": "File saved:",
        "read_file": "Enter file name (without .txt): ",
        "open_header": "=== File content ===",
        "file_not_found": "File not found.",
        "file_del_name": "Enter file name to delete (without .txt): ",
        "file_deleted": "✅ File deleted.",
        "file_del_protected": "⚠ You are trying to delete a SYSTEM file!\nThis will crash the OS.\nContinue? (y/n): ",
        "tasks_title": "=== Task planner ===",
        "tasks_add": "<add> Add task",
        "tasks_list": "<list> Show tasks",
        "tasks_clear": "<clear> Clear all",
        "tasks_del": "<del> Delete by number",
        "task_prompt": "Enter task: ",
        "task_rem_after": "Reminder in N minutes (blank — none): ",
        "task_added_with": "Task added! You will be reminded.",
        "task_added": "Task added without reminder.",
        "no_tasks": "No tasks.",
        "task_num": "Task number to delete: ",
        "enter_number": "Enter a number.",
        "rps_your": "Your choice (rock/paper/scissors): ",
        "rps_need": "Type rock / paper / scissors",
        "rps_pc": "Computer chose:",
        "rps_draw": "Draw!",
        "rps_win": "You win!",
        "rps_lose": "You lose!",
        "help_header": "----------------------",
        "help_calc": "<calc> Calculator",
        "help_ver": "<ver> Version",
        "help_guess": "<GuessNumberGame> Number Game",
        "help_repeater": "<repeater> Repeat Text",
        "help_sett": "<sett> Settings",
        "help_notepad": "<notepad> Notepad",
        "help_open": "<open> Open file",
        "help_delete": "<delete> Delete note",
        "help_tasks": "<tasks> Task planner",
        "help_rps": "<rps> Rock-Paper-Scissors",
        "help_crash": "<crash> BSOD / reboot",
        "help_terminalai": "<terminalai> TerminalAI assistant",
        "help_admin": "<admin> Admin mode",
        "help_exit": "<exit> Exit",
        "settings_1": "<lang> Change language",
        "settings_2": "<activation> Activate OS",
        "input_prompt": ">>> ",
        "lang_prompt": "<EN> English | <UA> Ukrainian | <RU> Russian",
        "already_activated": "Already activated.",
        "enter_key": "Enter activation key: ",
        "key_ok": "✅ Activated!",
        "key_bad": "❌ Wrong key."
    },
    "RU": {
        "welcome": "Добро пожаловать в TerminalOS!",
        "help_tip": "<help> чтобы увидеть больше команд",
        "enter_pass": "Введите пароль: ",
        "wrong_pass": "Неверный пароль.",
        "set_name": "Введите имя: ",
        "set_pass": "Задайте числовой пароль (4-16 цифр): ",
        "pass_num_only": "Пароль должен быть числовым!",
        "pass_len": "Пароль должен быть от 4 до 16 цифр!",
        "saving": "Сохранение пароля...",
        "select_lang": "Выберите язык:\n<EN> English\n<RU> Russian\n<UA> Ukrainian",
        "unknown_lang": "Неизвестный язык. По умолчанию English.",
        "activated": "✅ Активировано!",
        "not_activated": "⚠ Не активировано.",
        "requires_activation": "❌ Требуется активация.",
        "calc_menu": "1.+  2.-  3.*  4./",
        "again": "Ещё раз? (yes/no): ",
        "result": "Результат:",
        "enter_text": "Введите текст: ",
        "how_many": "Сколько раз?: ",
        "unknown_cmd": "Неизвестная команда. Напишите <help>.",
        "version": "TerminalOS v0.2.15 by Yan",
        "admin_on": "🔑 Режим администратора активирован.",
        "admin_bad": "❌ Неверный пароль администратора.",
        "admin_already": "Режим администратора уже включён.",
        "access_denied": "Доступ запрещён. Введите 'admin'.",
        "shutdown": "Выключение...",
        "bsod": "😵 Сбой системы. Нажмите любую клавишу для перезагрузки.",
        "crash_code": "Произошла ошибка! STOP CODE: ",
        "file_saved": "Файл сохранён:",
        "read_file": "Введите имя файла (без .txt): ",
        "open_header": "=== Содержимое файла ===",
        "file_not_found": "Файл не найден.",
        "file_del_name": "Имя файла для удаления (без .txt): ",
        "file_deleted": "✅ Файл удалён.",
        "file_del_protected": "⚠ Вы пытаетесь удалить СИСТЕМНЫЙ файл!\nСистема завершит работу с ошибкой.\nПродолжить? (y/n): ",
        "tasks_title": "=== Планировщик задач ===",
        "tasks_add": "<add> Добавить задачу",
        "tasks_list": "<list> Показать задачи",
        "tasks_clear": "<clear> Очистить",
        "tasks_del": "<del> Удалить по номеру",
        "task_prompt": "Введите задачу: ",
        "task_rem_after": "Напоминание через N минут (пусто — без напоминания): ",
        "task_added_with": "Задача добавлена! Напоминание будет показано.",
        "task_added": "Задача добавлена без напоминания.",
        "no_tasks": "Нет задач.",
        "task_num": "Номер задачи для удаления: ",
        "enter_number": "Введите число.",
        "rps_your": "Ваш выбор (камень/ножницы/бумага): ",
        "rps_need": "Нужно ввести: камень / ножницы / бумага",
        "rps_pc": "Компьютер выбрал:",
        "rps_draw": "Ничья!",
        "rps_win": "Вы победили!",
        "rps_lose": "Вы проиграли!",
        "help_header": "----------------------",
        "help_calc": "<calc> Калькулятор",
        "help_ver": "<ver> Версия",
        "help_guess": "<GuessNumberGame> Игра 'Угадай число'",
        "help_repeater": "<repeater> Повтор текста",
        "help_sett": "<sett> Настройки",
        "help_notepad": "<notepad> Блокнот",
        "help_open": "<open> Открыть файл",
        "help_delete": "<delete> Удалить заметку",
        "help_tasks": "<tasks> Планировщик задач",
        "help_rps": "<rps> Камень-ножницы-бумага",
        "help_crash": "<crash> BSOD/краш и перезагрузка",
        "help_terminalai": "<terminalai> TerminalAI ассистент",
        "help_admin": "<admin> Режим администратора",
        "help_exit": "<exit> Выход",
        "settings_1": "<lang> Сменить язык",
        "settings_2": "<activation> Активация ОС",
        "input_prompt": ">>> ",
        "lang_prompt": "<EN> English | <UA> Ukrainian | <RU> Russian",
        "already_activated": "Уже активировано.",
        "enter_key": "Введите ключ активации: ",
        "key_ok": "✅ Активировано!",
        "key_bad": "❌ Неверный ключ."
    },
    "UA": {
        "welcome": "Ласкаво просимо до TerminalOS!",
        "help_tip": "<help> щоб побачити більше команд",
        "enter_pass": "Введіть пароль: ",
        "wrong_pass": "Неправильний пароль.",
        "set_name": "Введіть ім'я: ",
        "set_pass": "Встановіть числовий пароль (4-16 цифр): ",
        "pass_num_only": "Пароль має бути числовим!",
        "pass_len": "Пароль має бути від 4 до 16 цифр!",
        "saving": "Збереження пароля...",
        "select_lang": "Оберіть мову:\n<EN> English\n<RU> Russian\n<UA> Ukrainian",
        "unknown_lang": "Невідома мова. Встановлено English.",
        "activated": "✅ Активовано!",
        "not_activated": "⚠ Не активовано.",
        "requires_activation": "❌ Потрібна активація.",
        "calc_menu": "1.+  2.-  3.*  4./",
        "again": "Ще раз? (yes/no): ",
        "result": "Результат:",
        "enter_text": "Введіть текст: ",
        "how_many": "Скільки разів?: ",
        "unknown_cmd": "Невідома команда. Введіть <help>.",
        "version": "TerminalOS v0.2.15 by Yan",
        "admin_on": "🔑 Режим адміністратора увімкнено.",
        "admin_bad": "❌ Невірний пароль адміністратора.",
        "admin_already": "Режим адміністратора вже увімкнено.",
        "access_denied": "Доступ заборонено. Введіть 'admin'.",
        "shutdown": "Вимкнення...",
        "bsod": "😵 Збій системи. Натисніть будь-яку клавішу для перезавантаження.",
        "crash_code": "Сталася помилка! STOP CODE: ",
        "file_saved": "Файл збережено:",
        "read_file": "Введіть назву файлу (без .txt): ",
        "open_header": "=== Вміст файлу ===",
        "file_not_found": "Файл не знайдено.",
        "file_del_name": "Назва файлу для видалення (без .txt): ",
        "file_deleted": "✅ Файл видалено.",
        "file_del_protected": "⚠ Ви намагаєтеся видалити СИСТЕМНИЙ файл!\nСистема аварійно завершить роботу.\nПродовжити? (y/n): ",
        "tasks_title": "=== Планувальник завдань ===",
        "tasks_add": "<add> Додати завдання",
        "tasks_list": "<list> Показати завдання",
        "tasks_clear": "<clear> Очистити",
        "tasks_del": "<del> Видалити за номером",
        "task_prompt": "Введіть завдання: ",
        "task_rem_after": "Нагадування через N хвилин (порожньо — без): ",
        "task_added_with": "Завдання додано! Нагадування буде показано.",
        "task_added": "Завдання додано без нагадування.",
        "no_tasks": "Немає завдань.",
        "task_num": "Номер завдання для видалення: ",
        "enter_number": "Введіть число.",
        "rps_your": "Ваш вибір (камінь/ножиці/папір): ",
        "rps_need": "Потрібно ввести: камінь / ножиці / папір",
        "rps_pc": "Комп'ютер обрав:",
        "rps_draw": "Нічия!",
        "rps_win": "Ви перемогли!",
        "rps_lose": "Ви програли!",
        "help_header": "----------------------",
        "help_calc": "<calc> Калькулятор",
        "help_ver": "<ver> Версія",
        "help_guess": "<GuessNumberGame> Гра 'Вгадайте число'",
        "help_repeater": "<repeater> Повтор тексту",
        "help_sett": "<sett> Налаштування",
        "help_notepad": "<notepad> Блокнот",
        "help_open": "<open> Відкрити файл",
        "help_delete": "<delete> Видалити нотатку",
        "help_tasks": "<tasks> Планувальник завдань",
        "help_rps": "<rps> Камінь-ножиці-папір",
        "help_crash": "<crash> BSOD/краш і перезавантаження",
        "help_terminalai": "<terminalai> Асистент TerminalAI",
        "help_admin": "<admin> Режим адміністратора",
        "help_exit": "<exit> Вихід",
        "settings_1": "<lang> Змінити мову",
        "settings_2": "<activation> Активація ОС",
        "input_prompt": ">>> ",
        "lang_prompt": "<EN> English | <UA> Ukrainian | <RU> Russian",
        "already_activated": "Вже активовано.",
        "enter_key": "Введіть ключ активації: ",
        "key_ok": "✅ Активовано!",
        "key_bad": "❌ Невірний ключ."
    }
}

# ===================== КОНФИГ =====================
def load_config():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return None

def save_config(cfg):
    os.makedirs(USERCONFIG_DIR, exist_ok=True)
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

# ===================== СЕТАП/ЛОГИН =====================
def first_install():
    global IsActivated, name, pass_create
    lang = "EN"
    typewriter(L[lang]["set_name"], end="")
    name = input().strip()
    while True:
        typewriter(L[lang]["set_pass"], end="")
        p = input().strip()
        if not p.isdigit():
            typewriter(L[lang]["pass_num_only"])
            continue
        if not (4 <= len(p) <= 16):
            typewriter(L[lang]["pass_len"])
            continue
        pass_create = int(p)
        break
    typewriter(L[lang]["saving"])
    time.sleep(1)
    typewriter(L[lang]["select_lang"])
    new_lang = input(">>> ").upper().strip()
    if new_lang not in L:
        typewriter(L[lang]["unknown_lang"])
        new_lang = "EN"

    cfg = {
        "username": name,
        "password": str(pass_create),
        "lang": new_lang,
        "activated": False
    }
    save_config(cfg)
    IsActivated = cfg["activated"]
    return new_lang

def login_and_start(lang):
    global pass_create, IsActivated, name
    cfg = load_config()
    if not cfg:
        lang = first_install()
        cfg = load_config()
    name = cfg.get("username", "")
    pass_create = int(cfg.get("password", "0") or 0)
    IsActivated = bool(cfg.get("activated", False))

    while True:
        try:
            attempt = int(input(L[lang]["enter_pass"]))
        except ValueError:
            typewriter(L[lang]["pass_num_only"])
            continue
        if attempt == pass_create:
            typewriter(L[lang]["welcome"])
            typewriter(L[lang]["help_tip"])
            Main_Menu(cfg["lang"])
            break
        else:
            print(L[lang]["wrong_pass"])

# ===================== INTERNET SEARCH & TERMINALAI =====================
def clean_text(text, query):
    text = re.sub(r'\[\w+\]|\[\d+\]', '', text)
    text = re.sub(r'\(\s*\d+\s*[а-яА-ЯёЁ]+\s*\[.*?\]\s*\d{4}.*?\)', '', text)
    text = ' '.join(text.split())
    query_words = query.lower().split()
    if not any(word in text.lower() for word in query_words):
        return None
    return text

def get_internet_answer(query):
    try:
        if "погода" in query.lower():
            query += " прогноз погоды site:sinoptik.ua | site:meteofor.com.ua | site:meteoprog.com"
        elif "роблокс" in query.lower() or "roblox" in query.lower():
            query = "Roblox википедия"

        with DDGS() as ddg:
            results = ddg.text(query, region='ru-ru', max_results=1)
        if not results:
            return "Не удалось найти точную информацию."

        url = results[0].get('href', '')
        if not url:
            return "Не удалось найти сайт для ответа."

        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.get(url, headers=headers, timeout=5)
        soup = BeautifulSoup(response.text, 'html.parser')
        paragraphs = soup.find_all('p')

        answer = ""
        sentence_count = 0
        for p in paragraphs:
            text = p.get_text().strip()
            if text and len(text) > 50:
                cleaned = clean_text(text, query)
                if cleaned:
                    answer += cleaned + " "
                    sentence_count += cleaned.count('.')
                    if sentence_count >= 2:
                        break
        time.sleep(1)
        return (answer[:300] + "...") if answer else "Ничего полезного не найдено."
    except Exception as e:
        return f"Ошибка: {e}"

def terminal_ai(lang):
    local_greetings = {
        "EN": "TerminalAI launched. Type your question or 'exit'.",
        "RU": "TerminalAI запущен. Введите вопрос или 'exit'.",
        "UA": "TerminalAI запущено. Введіть питання або 'exit'."
    }
    typewriter(local_greetings[lang])

    knowledge_base = {
        "привет": "Привет! Я TerminalAI.",
        "как дела": "У меня всё отлично!",
        "что ты умеешь": "Я могу искать ответы и помогать.",
        "какая сегодня погода": "Уточните запрос, например 'погода в Киеве'.",
        "кто ты": "Я TerminalAI.",
        "что такое python": "Python — это язык программирования."
    }

    while True:
        question = input("User> ").strip().lower()
        if question == "exit":
            typewriter("TerminalAI завершает работу.")
            break
        elif question:
            answer = knowledge_base.get(question)
            if answer:
                typewriter(f"TerminalAI> {answer}")
            else:
                typewriter("TerminalAI думает...")
                typewriter("TerminalAI> " + get_internet_answer(question))
        else:
            typewriter("TerminalAI> Введите вопрос.")

# ===================== FEATURES =====================
def guess_number_game(lang):
    messages = {
        "EN": ["Guess the number from 1 to 100", "Smaller", "Bigger", "Correct! Attempts:"],
        "RU": ["Угадайте число от 1 до 100", "Меньше", "Больше", "🎉 Правильно! Попыток:"],
        "UA": ["Вгадайте число від 1 до 100", "Менше", "Більше", "🎉 Правильно! Спроб:"]
    }
    print(messages[lang][0])
    number = randint(1, 100)
    count = 1
    while True:
        try:
            ans = int(input(">>> "))
            if ans > number:
                typewriter(messages[lang][1])
            elif ans < number:
                typewriter(messages[lang][2])
            else:
                typewriter(messages[lang][3], count)
                break
            count += 1
        except:
            typewriter("Enter a valid number!")

def calc_menu(lang):
    def add(x, y): return x + y
    def subtract(x, y): return x - y
    def multiply(x, y): return x * y
    def divide(x, y): 
        if y == 0:
            return "Division by zero!"
        return x / y

    ops = {"1": add, "2": subtract, "3": multiply, "4": divide}
    typewriter(L[lang]["calc_menu"])
    while True:
        choice = input(">>> ").strip()
        if choice in ops:
            try:
                num1 = float(input("Num 1: "))
                num2 = float(input("Num 2: "))
                print(L[lang]["result"], ops[choice](num1, num2))
            except ValueError:
                typewriter("Invalid input.")
            again = input(L[lang]["again"]).strip().lower()
            if again == "no":
                break
        else:
            typewriter("Unknown operation. Use 1/2/3/4.")

def repeat_text_list(text, times):
    return [text for _ in range(times)]

# --------- Notepad / Files ----------
def notepad():
    filename = input("File name (without .txt): ").strip() + ".txt"
    full_path = os.path.join(USERFILES_DIR, filename)
    typewriter("Enter text ('.exit' to save and quit):")
    lines = []
    while True:
        line = input()
        if line == ".exit":
            break
        lines.append(line)
    with open(full_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    typewriter(L[current_lang()]["file_saved"], full_path)

def open_file():
    fname = input(L[current_lang()]["read_file"]).strip() + ".txt"
    path = os.path.join(USERFILES_DIR, fname)
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            typewriter(L[current_lang()]["open_header"])
            typewriter(f.read())
    else:
        typewriter(L[current_lang()]["file_not_found"])

def delete_file():
    fname = input(L[current_lang()]["file_del_name"]).strip() + ".txt"
    # Разрешённая зона: только UserFiles
    user_path = os.path.join(USERFILES_DIR, fname)
    # Попытка удалить системное
    sys_path = os.path.join(SYSTEM_DIR, fname)
    if os.path.exists(sys_path) or os.path.abspath(sys_path) == os.path.abspath(CONFIG_PATH):
        cont = input(L[current_lang()]["file_del_protected"])
        if cont.lower() == "y":
            if os.path.exists(sys_path):
                os.remove(sys_path)
            bsod("0xDEAD0022Y")
        return
    if os.path.exists(user_path):
        try:
            os.remove(user_path)
            typewriter(L[current_lang()]["file_deleted"])
        except OSError as e:
            typewriter("Error deleting file:", e)
    else:
        typewriter(L[current_lang()]["file_not_found"])

# --------- Tasks ----------
def _parse_minutes_input(raw: str):
    raw = raw.strip()
    if not raw:
        return None
    try:
        minutes = int(raw)
        if minutes <= 0:
            return None
        return time.time() + minutes * 60
    except:
        return None

def check_task_reminders():
    if not tasks:
        return
    now = time.time()
    for t in tasks:
        due = t.get('due_ts')
        if due and now >= due and not t.get('notified'):
            typewriter(f"\n🔔 {t['text']}")
            t['notified'] = True

def task_manager():
    loc = L[current_lang()]
    typewriter(loc["tasks_title"])
    typewriter(loc["tasks_add"])
    typewriter(loc["tasks_list"])
    typewriter(loc["tasks_clear"])
    typewriter(loc["tasks_del"])
    choice = input(">>> ").strip().lower()

    if choice == "add":
        t = input(loc["task_prompt"]).strip()
        mins = input(loc["task_rem_after"]).strip()
        due_ts = _parse_minutes_input(mins)
        tasks.append({'text': t, 'due_ts': due_ts, 'added_ts': time.time(), 'notified': False})
        typewriter(loc["task_added_with"] if due_ts else loc["task_added"])
    elif choice == "list":
        if not tasks:
            typewriter(loc["no_tasks"])
        else:
            for i, t in enumerate(tasks, 1):
                if t['due_ts']:
                    mins_left = int(max(0, t['due_ts'] - time.time()) // 60)
                    status = f"(~{mins_left} min left)" if not t['notified'] else "(notified)"
                else:
                    status = "(no reminder)"
                typewriter(f"{i}. {t['text']} {status}")
    elif choice == "clear":
        tasks.clear()
        typewriter("OK")
    elif choice == "del":
        try:
            num = int(input(L[current_lang()]["task_num"]))
            if 1 <= num <= len(tasks):
                tasks.pop(num - 1)
                typewriter("OK")
            else:
                typewriter("Bad number.")
        except ValueError:
            typewriter(L[current_lang()]["enter_number"])
    else:
        typewriter(L[current_lang()]["unknown_cmd"])

# --------- RPS ----------
def rock_paper_scissors():
    loc = L[current_lang()]
    mapping = {
        "EN": ["rock", "paper", "scissors"],
        "RU": ["камень", "бумага", "ножницы"],
        "UA": ["камінь", "папір", "ножиці"]
    }
    opts = mapping[current_lang()]
    user = input(loc["rps_your"]).strip().lower()
    if user not in opts:
        typewriter(loc["rps_need"])
        return
    comp = choice(opts)
    typewriter(loc["rps_pc"], comp)
    win = ( (user==opts[0] and comp==opts[2]) or
            (user==opts[1] and comp==opts[0]) or
            (user==opts[2] and comp==opts[1]) )
    if user == comp:
        typewriter(loc["rps_draw"])
    elif win:
        typewriter(loc["rps_win"])
    else:
        typewriter(loc["rps_lose"])

# --------- BSOD ----------
def bsod(code=None):
    lang = current_lang()
    if code is None:
        code = choice([
            "0x0000001A", "0x0000003B", "0x0000007E",
            "0xC000021A", "0xDEADDEAD", "0xDEAD0022Y"
        ])
    typewriter("\n" + "="*50)
    typewriter(L[lang]["bsod"])
    typewriter(L[lang]["crash_code"] + code)
    typewriter("="*50 + "\n")
    typewriter("...")
    reboot()

def reboot():
    os.system('cls' if os.name == 'nt' else 'clear')
    cfg = load_config()
    lang = cfg.get("lang", "EN") if cfg else "EN"
    login_and_start(lang)

# --------- ADMIN ----------
def admin_panel():
    global admin_mode
    if not admin_mode:
        pwd = input("Admin password: ")
        if pwd == admin_pass:
            admin_mode = True
            typewriter(L[current_lang()]["admin_on"])
            typewriter("Hidden: <secretver>, <shutdown>, <crash>")
        else:
            typewriter(L[current_lang()]["admin_bad"])
    else:
        typewriter(L[current_lang()]["admin_already"])

# ===================== MAIN MENU =====================
def current_lang():
    cfg = load_config()
    return cfg.get("lang", "EN") if cfg else "EN"

def show_help():
    lang = current_lang()
    typewriter(L[lang]["help_header"])
    typewriter(L[lang]["help_calc"])
    typewriter(L[lang]["help_ver"])
    typewriter(L[lang]["help_guess"])
    typewriter(L[lang]["help_repeater"])
    typewriter(L[lang]["help_sett"])
    typewriter(L[lang]["help_notepad"])
    typewriter(L[lang]["help_open"])
    typewriter(L[lang]["help_delete"])
    typewriter(L[lang]["help_tasks"])
    typewriter(L[lang]["help_rps"])
    if IsActivated:
        typewriter(L[lang]["help_terminalai"])
        typewriter(L[lang]["help_tasks"])
    else:
        typewriter(L[lang]["help_terminalai"])
        typewriter(L[lang]["help_tasks"])
    typewriter(L[lang]["help_exit"])
    typewriter(L[lang]["help_header"])

def Main_Menu(lang):
    global IsActivated, admin_mode
    typewriter(L[lang]["activated"] if IsActivated else L[lang]["not_activated"])
    typewriter(L[lang]["help_tip"])

    while True:
        check_task_reminders()
        cmd = input(L[lang]["input_prompt"]).strip().lower()

        if cmd == "help":
            show_help()

        elif cmd == "ver":
            typewriter(L[lang]["version"])

        elif cmd == "guessnumbergame":
            guess_number_game(lang)

        elif cmd == "calc":
            calc_menu(lang)

        elif cmd == "repeater":
            word = input(L[lang]["enter_text"])
            try:
                count = int(input(L[lang]["how_many"]))
            except ValueError:
                typewriter("Need a number.")
                continue
            result = repeat_text_list(word, count)
            typewriter("\n".join(result))

        elif cmd == "sett":
            typewriter(L[lang]["settings_1"])
            typewriter(L[lang]["settings_2"])
            choice = input(">>> ").strip().lower()
            if choice == "lang":
                typewriter(L[lang]["lang_prompt"])
                new_lang = input(">>> ").upper().strip()
                if new_lang in L:
                    cfg = load_config() or {}
                    cfg["lang"] = new_lang
                    save_config(cfg)
                    lang = new_lang
                else:
                    typewriter("Unknown language.")
            elif choice == "activation":
                if IsActivated:
                    typewriter(L[lang]["already_activated"])
                else:
                    key = input(L[lang]["enter_key"])
                    if key == "OOEBE-KRTYM-QPLDD-ZXUWE-MICRO-SOFTL":
                        IsActivated = True
                        cfg = load_config() or {}
                        cfg["activated"] = True
                        save_config(cfg)
                        typewriter(L[lang]["key_ok"])
                    else:
                        typewriter(L[lang]["key_bad"])

        elif cmd == "terminalai":
            if IsActivated:
                terminal_ai(lang)
            else:
                typewriter(L[lang]["requires_activation"])

        elif cmd == "notepad":
            notepad()

        elif cmd == "open":
            open_file()

        elif cmd == "delete":
            delete_file()

        elif cmd == "tasks":
            if IsActivated:
                task_manager()
            else:
                typewriter(L[lang]["requires_activation"])

        elif cmd == "rps":
            rock_paper_scissors()

        elif cmd == "crash":
            bsod()

        elif cmd == "admin":
            admin_panel()

        elif cmd == "secretver":
            if admin_mode:
                typewriter("TerminalOS SECRET BUILD v0.2.15A")
            else:
                typewriter(L[lang]["access_denied"])

        elif cmd == "shutdown":
            if admin_mode:
                typewriter(L[lang]["shutdown"])
                sys.exit(0)
            else:
                typewriter(L[lang]["access_denied"])

        elif cmd == "exit":
            sys.exit(0)

        else:
            typewriter(L[lang]["unknown_cmd"])

# ===================== BOOT =====================
def boot_os():
    cfg = load_config()
    if not cfg:
        lang = first_install()
    else:
        lang = cfg.get("lang", "EN")
    login_and_start(lang)

# ===================== RUN =====================
if __name__ == "__main__":
    boot_os()
